package com.example.companyinspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyInSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
